﻿using System;

namespace Calculus3
{
    class MainClass
    {

        static int dotProduct(int[] vectorA,int[] vectorB)
        {
            int dotProductResult = 0;
            // Loop for calculate Dot Product
            for (int i = 0; i < 3; i++)
                dotProductResult = dotProductResult + vectorA[i] * vectorB[i];
            return dotProductResult;
        }
        // Function to find cross product of two vector array.
        static void crossProduct(int[] vectorA, int[] vectorB, int[] crossProductResult)

        {
            crossProductResult[0] = vectorA[1] * vectorB[2] - vectorA[2] * vectorB[1];
            crossProductResult[1] = vectorA[2] * vectorB[0] - vectorA[0] * vectorB[2];
            crossProductResult[2] = vectorA[0] * vectorB[1] - vectorA[1] * vectorB[0];
        }
        public static void Main()
        {
            int[] vectorA = new int[3];
            int[] vectorB = new int[3];
            int[] crossProductResult = new int[3];

            // User enter the values of two vectors
            for (int i = 0; i < vectorA.Length; i++)
            {
                Console.Write($"Enter vector A{i+1}: ");
                var input = Console.ReadLine();
                if (int.TryParse(input, out int result))
                    vectorA[i] = result;
                else
                    vectorA[i] = 0;
            }

            for (int i = 0; i < vectorB.Length; i++)
            {
                Console.Write($"Enter vector B{i + 1}: ");
                var input = Console.ReadLine();
                if (int.TryParse(input, out int result))
                    vectorB[i] = result;
                else
                    vectorB[i] = 0;
            }
            // Print out dot product result
            Console.Write("Dot product = ");
            Console.WriteLine(dotProduct(vectorA, vectorB));

            // Print out cross product result
            Console.Write("Cross product <x,y,z) = ");
            crossProduct(vectorA, vectorB, crossProductResult);

            for (int i = 0; i < 3; i++)
                Console.Write(crossProductResult[i] + " ");
        }
    }
}
